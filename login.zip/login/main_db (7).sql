-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 27, 2023 at 03:14 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `main_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `br_id` int(11) NOT NULL,
  `br_name` varchar(256) NOT NULL,
  `br_address` varchar(512) NOT NULL,
  `br_mail` varchar(50) NOT NULL,
  `br_phone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`br_id`, `br_name`, `br_address`, `br_mail`, `br_phone`) VALUES
(1001, 'Main Branch, Akola', '\'JANKALYAN\' OLD COTTON MARKET, AKOLA-444 001', 'aucb_main@aucbakola.com', '7242442251'),
(1002, 'Ramdaspeth,Akola', 'DATTA MANDIR CHOWK, RAMDAS PETH, AKOLA - 444 001', 'aucb_ramdaspeth@aucbakola.com', '7242434543'),
(1003, 'Karanja', 'MAIN RD, COTTON MARKET, NEAR APMC. KARANJA - 444 105', 'aucb_karnja@aucbakola.com', '7256222126'),
(1004, 'Mangrulpir', 'INFRONT OF SBI MAIN RD, MANGRULPIR - 444 403', 'aucb_mangrulpir@aucbakola.com', '7253230255'),
(1005, 'Adarsh Colony,Akola', 'POONAM COMPLEX,  GORAKSHAN RD, INCOME TAX CHOWK, AKOLA 444 004', 'aucb_adarshcolony@aucbakola.com', '7242459536'),
(1006, 'Balapur ', 'NEAR STATE BANK OF INDIA, BALAPUR DIST. AKOLA - 444 302', 'aucb_balapur@aucbakola.com', '7257232116'),
(1007, 'Tajnapeth,Akola', 'NEAR HDFC BANK, JILLHA PARISHAD ROAD, AKOLA - 444 001', 'aucb_tajnapeth@aucbakola.com', '7242438304'),
(1008, 'Murtizapur ', 'STATION ROAD, MURTIZAPUR  DIST AKOLA 444 107', 'aucb_murtizapur@aucbakola.com', '07256 243552'),
(1009, 'Hiwarkhed', 'MAIN ROAD, HIWARKHED 444103', 'aucb_hiwarkhed@aucbakola.com', '7258228209'),
(1010, 'Akot', 'LAKKAD GUNJ, HIWARKHED RD, AKOT DIST AKOLA - 444 101', 'aucb_akot@aucbakola.com', '7258224184'),
(1011, 'Malegaon', 'SHRI NAWASTHALE BUILDING MAIN RD. MALEGAON - 444 503', 'aucb_malegaon@aucbakola.com', '7254231271'),
(1012, 'Wadegaon', 'SHRI JAYRAM KALE COMPLEX, MAIN RD, WADEGAON - 444 502', 'aucb_wadegaon@aucbakola.com', '7257231144'),
(1013, 'Telhara', 'INFRONT OF  SHIVAJI SCHOOL, BUS STAND ROAD, TELHARA - 444 108', 'aucb_telhara@aucbakola.com', '7258231030'),
(1014, 'Sitabuldi,Nagpur', 'SAGAR TOWER, 2ND FLOOR, BESIDE NARESHCHANDRA & CO. PANDIT MALVIYA RD, SITABULDI, NAGPUR - 440 012', 'aucb_sitabuldi@aucbakola.com', '7122527199'),
(1015, 'Jalgaon', 'NATRAJ HALL OPP.PADMALAYA GOVT. REST HOUSE, JAYKISANWADI JALGAON - 425 001', 'aucb_jalgaon@aucbakola.com', '2572220197'),
(1016, 'Jaistambh Chowk, Amravati', 'MAHAVIR PLAZA COMPLEX, JAISTAMBH CHOWK, AMRAVATI - 444 601', 'aucb_jaisthambh@aucbakola.com', '7212679911'),
(1017, 'Yavatmal', 'SHARDA SADAN, AWDHOOT WADI, YAVATMAL - 445001', 'aucb_yavatmal@aucbakola.com', '7232241358'),
(1018, 'Daryapur', 'BANOSA ROAD, DARYAPUR - 444 803', 'aucb_daryapur@aucbakola.com', '7224234782'),
(1019, 'Rajapeth,Amravati', 'DEORANKAR NAGAR,NEAR SAMARTH HIGHSCHOOL,BADNERA ROAD, RAJAPETH AMRAVATI - 444601\r\n\r\n\r\n\r\n\r\n\r\n', 'aucb_rajapeth@aucbakola.com', '7212575501'),
(1020, 'Kalbadevi,Mumbai', '19,21/23 KARNANI HOUSE, VITHOBA LANE, VITTHALWADI, MUMBAI - 400 002', 'aucb_kalbadevi@aucbakola.com', '222406259'),
(1021, 'Gandhibag,Nagpur', '2ND FLOOR AHILYA COMPLEX NEAR MEDICINE MARKET AGRESEN CHOWK GANDHIBAG, NAGPUR - 440 002', 'aucb_gandhibag@aucbakola.com', '7122732750'),
(1022, 'APMC,Akola', 'GANGA NAGAR,BALAPUR ROAD,AKOLA - 444 001', 'aucb_apmc@aucbakola.com', '7242442250'),
(1023, 'Chandrapur', 'RAMKRUSHNA APPTT. GANJ WARD, CHANDRAPUR - 442 402', 'aucb_chandrapur@aucbakola.com', '7172256551'),
(1024, 'Wardha', 'RADHE COMPLEX SOCIELIST CHOWK, WARDHA - 442 008', 'aucb_wardha@aucbakola.com', '7152244554'),
(1025, 'Nanded', 'GROUND FLOOR, PATIL PLAZA, TAJ PATIL HOTEL,VISHNU COMPLEX, VIP ROAD,NANDED - 431605\r\n', 'aucb_nanded@aucbakola.com', '2462250370'),
(1026, 'Dabki Road,Akola', 'NEAR BHIKAMCHAND, KHANDELWAL HIGH SCHOOL,  GODBOLE PLOTS, DABKI ROAD, AKOLA - 444 002', 'aucb_dabkiroad@aucbakola.com', '7242439616'),
(1027, 'Civil Line,Akola ', '\'MAHALAXMI\'COMPLEX, OPP.BAGDI HOSITAL,AMANKHA PLOT,AKOLA-444001', 'aucb_civilline@aucbakola.com', '7242453317'),
(1028, 'Aurangabad', 'GOPICHAND COMPLEX, OPP. APNA HOSPITAL JALNA RD, AURANGABAD - 431 001', 'aucb_aurangabad@aucbakola.com', '2402344500'),
(1029, 'Nashik', 'NEAR MEHAR PLAZA BUILDING SAMANT HOUSE, ABOVE INDIAN BANK, OLD AGRA ROAD, NASHIK - 422 002', 'aucb_nasik@aucbakola.com', '2532318147'),
(1030, 'Brahman Sabha,Akola', 'JATHARPETH CHOWK, NEAR UTSAV MANGALKARYALAYA, AKOLA - 444 001', 'aucb_bsec@aucbakola.com', '7242490561'),
(1031, 'Subhashmarg,Indore', 'NETAJI SHUBHSAH MARG, INDORE -  452 007', 'aucb_subhashmarg@aucbakola.com', '7312531594'),
(1032, 'Malharganj,Indore', '19/2 DALLAI PATTI MALHARGANJ, INDORE- 452 002', 'aucb_malharganj@aucbakola.com', '7312411668'),
(1033, 'H.I.G. Colony,Indore', 'S-43, BEHIND KHRISTAN EMINENT SCHOOL MIG COLONY, INDORE - 452 010', 'aucb_higcolony@aucbakola.com', '7312553888'),
(1034, 'Sanyogitaganj,Indore', '47/2 SANYOGITA GANJ INDORE - 452 007', 'aucb_sanyogitaganj@aucbakola.com', '7312702355'),
(9999, 'Head Office', 'Jankalyan, 58-59, Toshniwal Layout, Near Govt. Milk Scheme, Murtizapur Road, Akola', 'aucb_main@aucbakola.com', '2453850-54');

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `c_id` int(50) NOT NULL,
  `city_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`c_id`, `city_name`) VALUES
(1, 'Metro City'),
(2, 'District Centre'),
(3, 'Taluka and Below Centre'),
(4, 'Nagpur'),
(5, 'Nashik'),
(6, 'Aurangabad'),
(7, 'Nanded'),
(8, 'Akola'),
(9, 'Amravati'),
(10, 'Indore');

-- --------------------------------------------------------

--
-- Table structure for table `designation`
--

CREATE TABLE `designation` (
  `d_id` int(11) NOT NULL,
  `designation_name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `designation`
--

INSERT INTO `designation` (`d_id`, `designation_name`) VALUES
(1, 'Dy. CEO/Chief Manager'),
(3, 'Branch Head'),
(5, 'Officer'),
(6, 'Executive'),
(7, 'Messenger/Driver');

-- --------------------------------------------------------

--
-- Table structure for table `travel_data`
--

CREATE TABLE `travel_data` (
  `username` varchar(50) NOT NULL,
  `tid` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `designation` text DEFAULT NULL,
  `branch` text DEFAULT NULL,
  `from_station` varchar(50) NOT NULL,
  `to_station` varchar(50) NOT NULL,
  `city` varchar(50) DEFAULT NULL,
  `max_da` int(100) NOT NULL,
  `max_lc` int(100) NOT NULL,
  `max_cc` int(100) NOT NULL,
  `departure_time` datetime NOT NULL,
  `arrival_time` datetime NOT NULL,
  `days_of_travel` int(20) NOT NULL,
  `Km_of_travel` int(100) NOT NULL,
  `da` varchar(5) NOT NULL,
  `da_rate` int(50) NOT NULL,
  `da_days` int(50) NOT NULL,
  `da_charges` int(50) NOT NULL,
  `lc` varchar(5) NOT NULL,
  `lc_rate` int(50) DEFAULT NULL,
  `lc_days` int(50) DEFAULT NULL,
  `lc_charges` int(50) DEFAULT NULL,
  `cc` varchar(5) NOT NULL,
  `cc_rate` int(50) DEFAULT NULL,
  `cc_days` int(50) DEFAULT NULL,
  `cc_charges` int(50) DEFAULT NULL,
  `ticket` varchar(5) NOT NULL,
  `totalno_ticket` int(50) NOT NULL,
  `totalamount_ticket` int(50) NOT NULL,
  `ttl` int(50) NOT NULL,
  `totalhour` int(11) NOT NULL,
  `Remark` text DEFAULT NULL,
  `status` text NOT NULL,
  `approval_date` varchar(100) DEFAULT NULL,
  `document_name` varchar(50) DEFAULT NULL,
  `lodging_bills` varchar(100) DEFAULT NULL,
  `tickets_document` varchar(100) DEFAULT NULL,
  `application_date` varchar(50) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `travel_data`
--

INSERT INTO `travel_data` (`username`, `tid`, `first_name`, `last_name`, `designation`, `branch`, `from_station`, `to_station`, `city`, `max_da`, `max_lc`, `max_cc`, `departure_time`, `arrival_time`, `days_of_travel`, `Km_of_travel`, `da`, `da_rate`, `da_days`, `da_charges`, `lc`, `lc_rate`, `lc_days`, `lc_charges`, `cc`, `cc_rate`, `cc_days`, `cc_charges`, `ticket`, `totalno_ticket`, `totalamount_ticket`, `ttl`, `totalhour`, `Remark`, `status`, `approval_date`, `document_name`, `lodging_bills`, `tickets_document`, `application_date`) VALUES
('user', 1, 'Saurabh', 'Bonde', 'Officer', '9999 Head Office', 'Akola', 'Amravati', 'Amravati', 625, 1500, 375, '2023-11-10 11:00:00', '2023-11-12 05:00:00', 2, 200, 'No', 625, 2, 1250, 'No', 1500, 2, 3000, 'No', 375, 2, 750, 'No', 2, 200, 5200, 0, 'Testing', 'In Process', '2023-10-27 18:09:14', NULL, 'Aman.pdf', 'Vitthal (1).pdf', '2023-10-27 18:05:54');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile_number` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `create_date` varchar(50) NOT NULL,
  `role` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `name`, `username`, `email`, `mobile_number`, `password`, `create_date`, `role`) VALUES
(1, 'Test_user', 'admin', 'admin@gmail.com', '1215515', 'Test@123', '2023-08-10', ''),
(2, '', 'user', 'pdingle@gmail.com', '', 'Prasad@123', '2023-08-18 08:18:07', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD UNIQUE KEY `br_id` (`br_id`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `designation`
--
ALTER TABLE `designation`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `travel_data`
--
ALTER TABLE `travel_data`
  ADD PRIMARY KEY (`tid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `c_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `designation`
--
ALTER TABLE `designation`
  MODIFY `d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `travel_data`
--
ALTER TABLE `travel_data`
  MODIFY `tid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
