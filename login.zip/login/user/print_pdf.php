<?php

	
	// if(isset($_SESSION['uid'])=="") {
  	//     header("Location:login.php");
	// }
	
    include("../tcpdf/tcpdf.php"); 
    include("header.php");
    include("../common/auth_session.php");
    require('../common/db.php');

    $userid=$_GET['uid'];
    $result=mysqli_query($con,"select * from travel_data where tid='$userid'");
    // while($result=mysqli_fetch_array($query))
    
    // $userid=$_GET['uid'];
    // Search for serial number in database
    //$sql = "SELECT * FROM bg_entry WHERE serial_number='$id'";
    //$result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $fname = $row['first_name'];
    $lname = $row['last_name'];
    $designation=$row['designation'];
    $branch = $row['branch'];
    $fromSation = $row['from_station'];
    $toSataion = $row['to_station'];
    $city=$row['city'];
    $Tod = $row['departure_time'];
    $Toa = $row['arrival_time'];
    $daysOfTravel = $row['days_of_travel'];
    $kmOfTravel = $row['Km_of_travel'];
    $da=$row['da'];
    $da_rate=$row['da_rate'];
    $da_days=$row['da_days'];
    $da_charges=$row['da_charges'];
    $lc=$row['lc'];
    $lc_rate=$row['lc_rate'];
    $lc_days=$row['lc_days'];
    $lc_charges=$row['lc_charges'];
    $cc=$row['cc'];
    $cc_rate=$row['cc_rate'];
    $cc_days=$row['cc_days'];
    $cc_charges=$row['cc_charges'];
    $ticket=$row['ticket'];
    $totalno_ticket=$row['totalno_ticket'];
    $totalamount_ticket=$row['totalamount_ticket'];
    $ttl=$row['ttl'];
    $totalhour=$row['totalhour'];
    $remark = $row['Remark'];
    $status= $row['status'];
    $new_doi =$row['application_date'];
     
}
 
     //number to word php function
function AmountInWords(float $ttl)
{
   $amount_after_decimal = round($ttl - ($num = floor($ttl)), 2) * 100;
   // Check if there is any number after decimal
   $amt_hundred = null;
   $count_length = strlen($num);
   $x = 0;
   $string = array();
   $change_words = array(0 => '', 1 => 'One', 2 => 'Two',
     3 => 'Three', 4 => 'Four', 5 => 'Five', 6 => 'Six',
     7 => 'Seven', 8 => 'Eight', 9 => 'Nine',
     10 => 'Ten', 11 => 'Eleven', 12 => 'Twelve',
     13 => 'Thirteen', 14 => 'Fourteen', 15 => 'Fifteen',
     16 => 'Sixteen', 17 => 'Seventeen', 18 => 'Eighteen',
     19 => 'Nineteen', 20 => 'Twenty', 30 => 'Thirty',
     40 => 'Forty', 50 => 'Fifty', 60 => 'SIXTY',
     70 => 'Seventy', 80 => 'Eighty', 90 => 'Ninety');
    $here_digits = array('', 'Hundred','Thousand','Lakh', 'Crore');
    while( $x < $count_length ) {
      $get_divider = ($x == 2) ? 10 : 100;
      $ttl = floor($num % $get_divider);
      $num = floor($num / $get_divider);
      $x += $get_divider == 10 ? 1 : 2;
      if ($ttl) {
       $add_plural = (($counter = count($string)) && $ttl > 9) ? 'S' : null;
       $amt_hundred = ($counter == 1 && $string[0]) ? ' And ' : null;
       $string [] = ($ttl < 21) ? $change_words[$ttl].' '. $here_digits[$counter]. $add_plural.' 
       '.$amt_hundred:$change_words[floor($ttl / 10) * 10].' '.$change_words[$ttl % 10]. ' 
       '.$here_digits[$counter].$add_plural.' '.$amt_hundred;
        }
   else $string[] = null;
   }
   $implode_to_Rupees = implode('', array_reverse($string));
   $get_paise = ($amount_after_decimal > 0) ? "And " . ($change_words[$amount_after_decimal / 10] . " 
   " . $change_words[$amount_after_decimal % 10]) . ' Paise' : '';
   return ($implode_to_Rupees ? $implode_to_Rupees . 'Rs. ' : '') . $get_paise;
}
         
?>

 <?php  

   $amt_words=$ttl;
   // nummeric value in variable

   $get_amount= AmountInWords($amt_words);
  
 class PDF extends TCPDF
     {
        // Page header
        function Header()
        {
        
        }

        // Page footer
        function Footer()
        {
            // Position at 1.5 cm from bottom
           $this->SetY(-10);
            // DejaVuSans italic
           $this->SetFont('FreeSans','BI',7);
            // Page number
            
            //$this->Cell(0,5,'<img src="img/aucbline.png">',0,0,'R');
            //$this->Image('img/aucbline.png',25,10,100);

	
           $this->Cell(0,5,'.',0,0,'R');
        }
        }
        
    
        // Instanciation of inherited class
        $pdf = new PDF();
        $pdf->SetMargins(20, 5, 10, true);  
        $pdf->AddPage();
        $pdf->SetFont('FreeSerif','',12);

    // set document information
        $pdf->SetCreator(PDF_CREATOR);
        $pdf->SetAuthor('THE AKOLA URBAN CO-OPERATIVE BANK LTD.,AKOLA');
        $pdf->SetSubject('TA');
        $pdf->Ln(15);
//START CONTENT
$html = '
<h2 style="text-align:center">THE AKOLA URBAN CO-OPERATIVE BANK LTD., AKOLA</h2><br>
<h4 style="text-align:center">(MULTISTATE SCHEDULED BANK)</h4><br>
<h3 style="text-align:center">TA Bill Details</h3>  
<hr>
<br><br><h5 style="text-align:right;"><b>Application Date: '.$new_doi.'</b></h5>    
   
<table  style="width: 354px;"  border="0" cellspacing="1" cellpadding="1">
<tbody>
<tr>
<td style="width: 165px;"><strong>First Name</strong></td>
<td style="width: 15px; text-align: center;"><strong>:</strong></td>
<td style="width: 165px;"><strong>'.$fname.'</strong></td>
</tr>
<tr>
<td style="width: 165px;"><strong>Last Name</strong></td>
<td style="width: 15px; text-align: center;"><strong>:</strong></td>
<td style="width: 165px;"><strong>'.$lname.'</strong></td>
</tr>

<tr>
<td style="width: 165px;"><strong>Branch</strong></td>
<td style="width: 15px; text-align: center;"><strong>:</strong></td>
<td style="width: 165px;"><strong>'.$branch.'</strong></td>
</tr>
<tr>
<td style="width:165px;"><strong>Designation</strong></td>
<td style="width: 15px; text-align: center;"><strong>:</strong></td>
<td style="width: 165px;"><strong>'.$designation.'</strong></td>
</tr>
<tr>
<td style="width: 165px;"><strong>Travelling City Type</strong></td>
<td style="width: 15px; text-align: center;"><strong>:</strong></td>
<td style="width: 165px;"><strong>'.$city.'</strong></td>
</tr>
</table>    

<style>
.alpha th,
.alpha td,
.alpha tr
{

    border-collapse:collapse;
    border:1px solid black;
    cellspacing="1";
    cellpadding="2";
}
</style>
<p><strong>Journey Details:</strong></p>
<table class="alpha" style="width: 354px;">
<tr>
<th style="width: 85px;">From Station</th>
<th style="width: 85px;">To Station</th>
<th style="width: 85px;">Kilo Meters of Travel</th>
<th style="width: 85px;">Time of Departure</th>
<th style="width: 85px;">Time of Arrival</th>
<th style="width: 85px;">Days of Travel</th>
</tr>

<tr>
<td>'.$fromSation.'</td>
<td>'.$toSataion.' </td>
<td>'.$kmOfTravel.' km</td>
<td>'.$Tod.'</td>
<td>'.$Toa.'</td>
<td>'.$daysOfTravel.' days</td>
</tr>

</table><br><br>

<style>
.beta th,
.beta td,
.beta tr
{

    border-collapse:collapse;
    border:1px solid black;
    cellspacing="1";
    cellpadding=3;
}
.gama th,
.gama td,
.gama tr
{

    border-collapse:collapse;
    border:1px solid black;
    cellspacing="1";
    cellpadding=3;
}
</style>

<table>
<tr>
<td style="width: 256px;"><strong>DA Details:</strong></td>
<td style="width: 300px;"><strong>Lodging Charges Details :</strong></td>
</tr> 
</table><br><br>

<table>
<tr>

<td>
<table  class="beta" style="width: 300px;" >
<tr>
<td style="width: 170px;">&nbsp;Do you want to fill DA charges?</td>
<td style="width: 50px;">&nbsp;'.$da.' </td>
</tr>
<tr>
<td style="width: 170px;">&nbsp;DA Rate</td>
<td style="width: 50px;">&nbsp;'.$da_rate.' </td>
</tr>
<tr>
<td style="width: 170px;">&nbsp;No. of days</td>
<td style="width: 50px;">&nbsp;'.$da_days.' </td> 
</tr>
<tr>
<td style="width: 170px;">&nbsp;DA Charges</td>
<td style="width: 50px;">&nbsp;'.$da_charges.' </td>
</tr>
</table><br><br>
</td>

<td>

<table class="gama" style="width: 300px;" >
<tr>
<td style="width: 200px;">&nbsp;Do you want to fill Lodging charges??</td>
<td style="width: 50px;">&nbsp;'.$lc.' </td>
</tr>
<tr>
<td style="width: 200px;">&nbsp;Lodging Rate</td>

<td style="width: 50px;">&nbsp;'.$lc_rate.' </td>
</tr>
<tr>
<td style="width: 200px;">&nbsp;No. of days</td>

<td style="width: 50px;">&nbsp;'.$lc_days.' </td> 
</tr>
<tr>
<td style="width: 200px;">&nbsp;Lodging Charges</td>

<td style="width: 50px;">&nbsp;'.$lc_charges.' </td>
</tr>
</table><br><br>

</td>
</tr>
</table>


<style>
.delta th,
.delta td,
.delta tr
{

    border-collapse:collapse;
    border:1px solid black;
    cellspacing="1";
    cellpadding=3;
}
.theta th,
.theta td,
.theta tr
{

    border-collapse:collapse;
    border:1px solid black;
    cellspacing="1";
    cellpadding=3;
}
</style>

<table>
<tr>
<td style="width: 256px;"><strong>Conveyance Charges Details:</strong></td>
<td style="width: 300px;"><strong>Ticket Details :</strong></td>
</tr> 
</table><br><br>

<table>
<tr>

<td>
<table  class="delta" style="width: 300px;" >
<tr>
<td style="width: 170px;">&nbsp;Do you want to fill Conv. charges?</td>
<td style="width: 50px;">&nbsp;'.$cc.' </td>
</tr>
<tr>
<td style="width: 170px;">&nbsp;Conveyance Rate</td>
<td style="width: 50px;">&nbsp;'.$cc_rate.' </td>
</tr>
<tr>
<td style="width: 170px;">&nbsp;No. of days</td>
<td style="width: 50px;">&nbsp;'.$cc_days.' </td> 
</tr>
<tr>
<td style="width: 170px;">&nbsp;Conveyance Charges</td>
<td style="width: 50px;">&nbsp;'.$cc_charges.' </td>
</tr>
</table><br><br>
</td>

<td>

<table class="theta" style="width: 300px;" >
<tr>
<td style="width: 200px;">&nbsp;Do you want to fill Tickets charges?</td>
<td style="width: 50px;">&nbsp;'.$ticket.' </td>
</tr>
<tr>
<td style="width: 200px;">&nbsp;Total no of tickets</td>

<td style="width: 50px;">&nbsp;'.$totalno_ticket.' </td>
</tr>

<tr>
<td style="width: 200px;">&nbsp;Total ticket amount</td>

<td style="width: 50px;">&nbsp;'.$totalamount_ticket.' </td>
</tr>
</table><br><br>

</td>
</tr>
</table>

<style>
.zeta th,
.zeta td,
.zeta tr
{

    border-collapse:collapse;
    border:1px solid black;
    cellspacing="1";
    cellpadding="2";
}
</style>

<br><br><table class="zeta" style="width: 354px;">
<tr>
<th style="width: 85px;">Total TA Amount</th>
<th style="width: 125px;">Total TA Amount (In Words)</th>
<th style="width: 85px;">Remark</th>
<th style="width: 85px;">Status</th>
</tr>

<tr>
<td><strong>'.$ttl.'</strong></td>
<td ><strong>'.$get_amount.'</strong></td>
<td>'.$remark.' </td>
<td>'.$status.'</td>
</tr>
</table>
<br><br>
<hr>
<br><br>
<table>
<tr>
<td>
<p style="text-align:left; font-size: 10px;" >Yours Sincerely,</p><br><br>

<b style="text-align:left; font-size: 10px;">Applicant: </b>'.$fname.'&nbsp;'.$lname.'
</td>

<td>
<p style="font-size: 10px;" ></p><br><br>
<b style="font-size: 10px;">Branch Manager:</b><br>
<b style="font-size: 10px;">Date:</b>
</td>
<td>
<p style="font-size: 10px;" ></p><br><br>
<b style="font-size: 10px;">Officer</b><br>
<b style="font-size: 10px;">Date:</b>
</td>
</tr>
</table>


';

  
            $pdf->writeHTML($html);
            // Logo
            // $pdf->Image('tmp/tmp_qr.png',165,75,30);
    
    
    // echo "$pdfname";
    ob_end_clean();
    $pdf->Output("$fname.pdf", 'I');

?>
