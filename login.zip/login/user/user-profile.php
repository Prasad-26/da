<link rel="icon" href="fevicon.png"/>
<?php
include("header.php");
include("../common/auth_session.php");
require('../common/db.php');

$userid=$_GET['uid'];

if(isset($_POST['submit'])){
    
$target_path = "userbillsubmitted/";
$target_path = $target_path.basename($_FILES['fileToUpload']['name']);  

if(move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $target_path)) {  
    echo "<script>alert('Your form has been submitted successfully.')</script>"; 
    // print_r($_FILES); 
 
} else{  
    echo "<script>alert('Your form has not been submitted successfully.')</script>";
}

 $fnam=$_FILES['fileToUpload']['name'];
 $result=mysqli_query($con,"update travel_data set document_name='$fnam' where tid='$userid'");

}



$query=mysqli_query($con,"select * from travel_data where tid='$userid'");
while($result=mysqli_fetch_array($query))



{?>

                        <div class="card mb-4">
                        <!-- <h5 class="mt-2"><?php echo $result['name'];?>'s TA Bill</h5> -->
                            <div class="card-body" style=" 
 background:linear-gradient(rgba(255,255,255,0.9), rgba(255,255,255,0.9)),url('aucb_wm.png') no-repeat;
 background-position: center;
 background-size:45%;">
                           
                               <strong><p style="font-size:20px;text-decoration: underline;">User Details:</p></strong>
                                <table class="table table-bordered table-striped " >
                                                              
                               
                                    <tr>

                                    <tr>
     
                                       <th>First Name:</th>

                                       <td ><?php echo $result['first_name'];?></td> </tr>
                                       
                                    <tr><th>Last Name:</th>
                                    <td><?php echo $result['last_name'];?></td> </tr>   
                                       <tr> <th>Branch</th>
                                       <td><?php echo $result['branch'];?></td> </tr>
                                   
                                    <tr>
                                       <th>Designation</th>
                                       <td><?php echo $result['designation'];?></td></tr>
                                       <tr><th>City Type</th>
                                       <td ><?php echo $result['city'];?></td>
                                    </tr>
                                  
</table><strong><p style="font-size:20px;text-decoration: underline;">Travel Details:</p></strong>
<table class="table table-bordered table-striped" >
                                   

                                    <thead>
                                        <tr>
                                        <th scope="col">From Station</th>
                                        <th scope="col">To Station</th>
                                        <th scope="col">Total Kilometer of Travel</th>
                                        <th scope="col">Departure Time</th>
                                        <th scope="col">Arrival Time</th>
                                        <th scope="col">Days Of Travel</th>
                                        </tr>
                                     </thead>
                                    <tbody>
                                        <tr>
                                        <td><?php echo $result['from_station'];?></td>
                                        <td><?php echo $result['to_station'];?></td>
                                        <td><?php echo $result['Km_of_travel'];?>&nbsp;km</td>
                                        <td><?php echo $result['departure_time'];?></td>
                                        <td><?php echo $result['arrival_time'];?></td>
                                        <td ><?php echo $result['days_of_travel'];?></td>
                                        </tr>
                                   </tbody>

                                     
                                       
</table><br>
<table class="table table-bordered table-striped table-primary" >
<thead>
                                        <tr>
                                        <th scope="col">DA was provided by Bank/Organization?</th>
                                        <th scope="col">DA Rate</th>
                                        <th scope="col">No of Days:</th>
                                        <th scope="col">DA Charges: </th>
                                        </tr>
                                     </thead>
                                    <tbody>
                                        <tr>
                                        <td><?php echo $result['da'];?></td>
                                        <td><?php echo $result['da_rate'];?></td>
                                        <td><?php echo $result['da_days'];?></td>
                                        <td><?php echo $result['da_charges'];?></td>
                                        
                                        </tr>
                                   </tbody>

                                   </table><br>

                                   <table class="table table-bordered table-striped table-success" style="width:30 px;"  >
                                <thead>
                                        <tr>
                                        <th scope="col" >Lodging charges was provided by Bank/Organization?</th>
                                        <th scope="col">Lodging Rate</th>
                                        <th scope="col">No of Days:</th>
                                        <th scope="col">Lodging Charges:</th>
                                        </tr>
                                     </thead>
                                    <tbody>
                                        <tr>
                                        <td><?php echo $result['lc'];?></td>
                                        <td><?php echo $result['lc_rate'];?></td>
                                        <td><?php echo $result['lc_days'];?></td>
                                        <td><?php echo $result['lc_charges'];?></td>
                                        
                                        </tr>
                                   </tbody>

                                   </table><br>

                                   <table class="table table-bordered table-striped table-danger" >
                                <thead>
                                        <tr>
                                        <th scope="col">Conveyance charges was provided by Bank/Organization?</th>
                                        <th scope="col">Conveyance Rate</th>
                                        <th scope="col">No of Days:</th>
                                        <th scope="col">Conveyance Charges:</th>
                                        </tr>
                                     </thead>
                                    <tbody>
                                        <tr>
                                        <td><?php echo $result['cc'];?></td>
                                        <td><?php echo $result['cc_rate'];?></td>
                                        <td><?php echo $result['cc_days'];?></td>
                                        <td><?php echo $result['cc_charges'];?></td>
                                        
                                        </tr>
                                   </tbody>

                                   </table><br>
                                   <table class="table table-bordered table-striped" >
                                <thead>
                                        <tr>
                                        <th scope="col">Railway/Bus tickets booked by Bank/Organization?</th>
                                        <th scope="col">Total no of tickets</th>
                                        <th scope="col">Total ticket amount</th>
                                        
                                        </tr>
                                     </thead>
                                    <tbody>
                                        <tr>
                                        <td ><?php echo $result['ticket'];?></td></td>
                                        <td><?php echo $result['totalno_ticket'];?></td>
                                        <td><?php echo $result['totalamount_ticket'];?></td>
                                                                                
                                        </tr>
                                   </tbody>

                                   </table><br>
                                                                       
                                   <table class="table table-bordered table-striped" >
                                <thead>
                                        <tr>
                                        <th scope="col">Total Amount</th>
                                        <th scope="col">Remark</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Application Date</th>
                                        <th scope="col">Approve/Reject Date</th>
                                        </tr>
                                     </thead>
                                    <tbody>
                                        <tr>
                                        <td >Rs.<?php echo $result['ttl'];?></td></td>
                                        <td><?php echo $result['Remark'];?></td>
                                        <td id="sta"><?php echo $result['status'];
                                         if($result['status']=='Approved')
                                         {
                                            echo '<style>
                                                      #sta{color:green;font-weight:bold;}
                                                 </style>';
                                         }
                                         if($result['status']=='Rejected')
                                         {
                                             echo '<style>
                                                       #sta{color:red;font-weight:bold;}
                                                 </style>';
                                         }
                                        ?></td>
                                        <td><?php echo $result['application_date'];?></td>
                                        <td><?php echo $result['approval_date'];?></td>

                                        
                                        </tr>
                                   </tbody>

                                   </table><br>
                                   <br>                   
<table>
   
                               <tr>
                               
                             
                              <?php $ret=mysqli_query($con,"SELECT document_name FROM travel_data WHERE tid='$userid'");
                              while($row=mysqli_fetch_array($ret))
                              {if($row['document_name']==null) {?>   
                              <tr>
                                    <p style="color:red">1. *First Click on Print Button for Printing TA Bill</p>
                                    <p style="color:red">2. *Then Upload Sanctioned TA Bill and Click on Submit</p>
                            </tr>
                            <a class="btn btn-primary" href="manage_user.php" name="back" id="btn" >Back</a>&nbsp;
                              <a href="edit.php?uid=<?php echo $result['tid'];?>" class="btn btn-warning" >Edit TA Bill</a>&nbsp;  
                              <a href="print_pdf.php?uid=<?php echo $result['tid'];?>" type="button" target="_blank" class="btn btn-info">Print</a> &nbsp;
                              <form method="post" action="#" enctype="multipart/form-data">
                              <input  type="file" id="fileToUpload" name="fileToUpload"  class="btn btn-success" style="font-size:small;" required/>
                              <label for="img">Upload Approved TA Bill here</label> &nbsp;&nbsp;
                              <button class="btn btn-primary" name="submit" id="btn" >Submit</button>
                              </form>
                                  
                             <?php } }?>        </tr>               
</table>                
                               
</div>
                               
                            
                            
                           
                            </div>
                        </div>

                        
<?php 
} 
?>
                    


                    </div>
                </main>
                
            </div>
        </div>
      
        

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
