<script type="text/javascript" src="condition.js"></script>
<link rel="icon" href="fevicon.png" />

<?php
//include auth_session.php file on all user panel pages
include("header.php");
include("../common/auth_session.php");
require('../common/db.php');
// include("condition.js");

$username = $_SESSION['username'];



if (isset($_POST['submit'])) {


  $fname = $_POST['fname'];
  $lname = $_POST['lname'];
  $designation = $_POST['designation'];
  $branch = $_POST['branch'];
  $fromSation = $_POST['fromSation'];
  $toSataion = $_POST['toSataion'];
  $rfromSation = $_POST['rfromSation'];
  $rtoSataion = $_POST['rtoSataion'];
  $city = $_POST['city'];
  $Tod = $_POST['Tod'];
  $Toa = $_POST['Toa'];
  $daysOfTravel = $_POST['daysOfTravel'];
  $kmOfTravel = $_POST['kmOfTravel'];
  $daradio = $_POST['daoptradio'];
  $da45 = $_POST['da45'];
  $da5 = $_POST['da5'];
  $da6 = $_POST['da6'];
  $lcradio = $_POST['lcoptradio'];
  $lc45 = $_POST['lc45'];
  $lc5 = $_POST['lc5'];
  $lc6 = $_POST['lc6'];
  $ccradio = $_POST['ccoptradio'];
  $cc4 = $_POST['cc4'];
  $cc5 = $_POST['cc5'];
  $cc6 = $_POST['cc6'];
  $ttradio = $_POST['ticketoptradio'];
  $tt4 = $_POST['tt4'];
  $tt5 = $_POST['tt5'];
  $ttl = $_POST['ttl'];
  $remark = $_POST['remark'];
  $cdac = $_POST['cdac'];
  $clc = $_POST['clc'];
  $ccc = $_POST['ccc'];

  $fnam2 = $_FILES['fileUpload']['name']; //lodging bills is fileToUpload
  // $application_date=now();
  // $fileUpload = $_POST['fileUpload'];


  //echo print_r($_POST);
  if ($ttradio == 'Yes') {
    $my_folder = "usertickets/";
    $uploadOk = true;
    $FileType = pathinfo($target_file, PATHINFO_EXTENSION);
    // Check if file already exists
    if (file_exists($my_folder . $_FILES['fileToUpload']['name'])) {
      echo '<script>alert("SAME FILE NAME ALREADY EXIST!. KINDLY CHANGE FILE NAME & FILL FORM AGAIN.")</script>';
      $uploadOk = false;
      header("Refresh:0;url=user_dashboard.php");
      exit();
    } else if ($uploadOk !== false) {
      move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $my_folder . $_FILES['fileToUpload']['name']);
      $fnam1 = $_FILES['fileToUpload']['name'];
      echo '<script>Received file</script>';

      // mysqli_query($con, $query);
    }
  }

  if ($lcradio == 'Yes') {
    $my_folder = "userlodgingbills/";
    $uploadOk = true;
    $FileType = pathinfo($target_file, PATHINFO_EXTENSION);
    // Check if file already exists
    if (file_exists($my_folder . $_FILES['fileUpload']['name'])) {
      echo '<script>alert("SAME FILE NAME ALREADY EXIST!. KINDLY CHANGE FILE NAME & FILL FORM AGAIN.")</script>';
      $uploadOk = false;
      header("Refresh:0;url=user_dashboard.php");
      exit();
    } else if ($uploadOk !== false) {
      move_uploaded_file($_FILES['fileUpload']['tmp_name'], $my_folder . $_FILES['fileUpload']['name']);
      $fnam2 = $_FILES['fileUpload']['name'];
      echo '<script>Received file</script>';

      // mysqli_query($con, $query);
    }
  }


  $query = "insert into travel_data(username,first_name,last_name,designation,branch,from_station,to_station,city,max_da,max_lc,max_cc,departure_time,arrival_time,
days_of_travel,Km_of_travel,da,da_rate,da_days,da_charges,lc,lc_rate,lc_days,lc_charges,cc,cc_rate,cc_days,cc_charges,ticket,totalno_ticket,
totalamount_ticket,ttl,lodging_bills,tickets_document,Remark,status,application_date) 

values('$username','$fname','$lname','$designation','$branch','$fromSation','$toSataion','$city','$cdac','$clc','$ccc','$Tod','$Toa','$daysOfTravel','$kmOfTravel','$daradio',
'$da45','$da5','$da6','$lcradio','$lc45','$lc5','$lc6','$ccradio','$cc4','$cc5','$cc6','$ttradio','$tt4','$tt5','$ttl','$fnam2','$fnam1','$remark','In Process',now())";

  if (mysqli_query($con, $query)) {
    echo '<script>alert("Now,upload manager approved TA bill");</script>';
    header("Location:manage_user.php");
  } else {
    echo "Error: " . $query . "<br>" . mysqli_error($con);
  }



  // $result2=mysqli_query($con,"update travel_data set lodging_bills='$fnam2' ");

  // header("Location:manage_user.php");


}


?>

<div class="container">
  <div class="form">
    <h5 class="text-center">Enter Travel Bill Details</h5>
    <hr>
    <form method="POST" action="#" enctype="multipart/form-data" style=" 
 background:linear-gradient(rgba(255,255,255,0.9), rgba(255,255,255,0.9)),url('aucb_wm.png') no-repeat;
 background-position: center;
 background-size:55%;">
      <div class="row">
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">First Name</label>
          <input type="text" class="form-control" style="text-transform: capitalize;" name="fname" placeholder="First Name" aria-label="First name" required>
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Last Name</label>
          <input type="text" class="form-control" style="text-transform: capitalize;" name="lname" placeholder="Last Name" aria-label="First name" required>
        </div>
        <div class="col">
          <label for="branch" class="form-label">Select your branch</label>
          <select class="form-select" id="branch" aria-label="First Name" name='branch' required>
            <option value="">Select Branch</option>
            <?php
            $sql = mysqli_query($con, "SELECT * From branches");
            $row = mysqli_num_rows($sql);
            while ($row = mysqli_fetch_array($sql)) {
              echo "<option value='" . $row['br_id'] . " " . $row['br_name'] . "'>" . $row['br_id'] . " " . $row['br_name'] . "</option>";
            }
            ?>
          </select>
        </div>
        <div class="col">
          <label for="desig" class="form-label">Designation</label>
          <select class="form-select" id="desig" aria-label="First Name" name="designation" onChange="myFunction2()" required>
            <option value="$designation">Select your designation</option>
            <?php
            $sql = mysqli_query($con, "SELECT * From designation");
            $row = mysqli_num_rows($sql);
            while ($row = mysqli_fetch_array($sql)) {
              echo "<option value='" . $row['designation_name'] . "'>" . $row['designation_name'] . "</option>";
            }
            ?>
          </select>
        </div>
        
      </div>



      <br>
      <hr>
      <div class="row">
        <h6 class="text-left">First Part of Journey</h6>
      </div>
      <div class="row">
        <!-- <div class="col">
      <label for="exampleFormControlInput1" class="form-label">Total</label>
        <input  readonly type="number" class="form-control" id="cdac" name="cdac" placeholder="DA Charges" aria-label="Last name" >
    </div> -->
    
        <div class="col">
          <label for="city" class="form-label">Travelling City Type</label>
          <select class="form-select" aria-label="First Name" id="city" name='city' onChange="myFunction2()" required>
            <option value="">Select City</option>
            <?php
            $sql = mysqli_query($con, "SELECT * From city");
            $row = mysqli_num_rows($sql);
            while ($row = mysqli_fetch_array($sql)) {
              echo "<option value='" . $row['city_name'] . "'>" . $row['city_name'] . "</option>";
            }
            ?>
          </select>
        </div>

        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Max. DA Charges (For 24hrs)</label>
          <input readonly type="number" class="form-control" id="cdac" name="cdac" placeholder="DA Charges" aria-label="Last name">
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Max. Lodg. Charges (For 24hrs)</label>
          <input readonly type="number" class="form-control" id="clc" name="clc" placeholder="Lodging Charges" aria-label="Last name">
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Max. Conv. Charges (For 24hrs)</label>
          <input readonly type="number" class="form-control" id="ccc" name="ccc" placeholder="Conveyance Charges" aria-label="Last name">
        </div>

      </div>
      <br>
      <div class="row">
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">From Station</label>
          <input type="text" class="form-control" style="text-transform: capitalize;" name="fromSation" placeholder="From Station" aria-label="Last name" required>
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">To Station</label>
          <input type="text" class="form-control" style="text-transform: capitalize;" name="toSataion" placeholder="To Station" aria-label="Last name" required>
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Total KMs of Travel</label>
          <input type="number" class="form-control" name="kmOfTravel" placeholder="Total Kilo-Meters of Travel" aria-label="First name" required>
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Start Date of Journey</label>
          <input type="datetime-local" class="form-control" id="Tod" name="Tod" placeholder="Time Of Diparture" aria-label="First name" required>
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">End Date of Journey</label>
          <input type="datetime-local" class="form-control" id="Toa" name="Toa" placeholder="Time Of Arrival" aria-label="Last name" onChange="myFunction()" required>
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Total Days of Travel</label>
          <input readonly type="number" class="form-control" id="daysOfTravel" name="daysOfTravel" placeholder="Total Days of Travel" aria-label="Last name" required>
        </div>
      </div>
      <br>

      <div class="row">
        <div class="col-3">
          <p>Do you want to fill DA Charges?</p>
          <input type="radio" class="form-check-input" id="daradio" name="daoptradio" value="Yes" onclick="dashow2();multiply();" required> Yes
          <label class="form-check-label" for="daradio"> </label>
          <input type="radio" class="form-check-input" id="daradio" name="daoptradio" value="No" onclick="dashow1();"> No
          <label class="form-check-label" for="daradio"></label>
        </div>
        <div class="col" id="da1" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">DA Rate Per DAY:</label>
          <input readonly min="0" type="number" class="form-control" id="da45" name="da45" placeholder="Amount" aria-label="Last name" onChange="multiply()">
        </div>
        <div class="col" id="da2" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">No of Days:</label>
          <input type="number" min="0" class="form-control" id="da5" name="da5" placeholder="Days" aria-label="Last name" onChange="multiply()">
        </div>
        <div class="col" id="da3" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">DA Charges:</label>
          <input readonly type="number" class="form-control" id="da6" name="da6" placeholder="Total Amount" aria-label="Last name">
        </div>
      </div>

      <br>

      <div class="row">
        <div class="col-3">
          <p>Do you want to fill Lodging Charges?</p>
          <input type="radio" class="form-check-input" id="lcradio" name="lcoptradio" value="Yes" onclick="lcshow2();multiply();" required> Yes
          <label class="form-check-label" for="lcradio"> </label>
          <input type="radio" class="form-check-input" id="lcradio" name="lcoptradio" value="No" onclick="lcshow1();"> No
          <label class="form-check-label" for="lcradio"></label>
        </div>
        <div class="col" id="lc1" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Lodging Rate Per DAY:</label>
          <input readonly type="number" class="form-control" id="lc45" name="lc45" placeholder="Amount" aria-label="Last name" onChange="multiply2()">
        </div>
        <div class="col" id="lc2" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">No of Days:</label>
          <input type="number" class="form-control" id="lc5" name="lc5" placeholder="Days" aria-label="Last name" onChange="multiply2()">
        </div>
        <div class="col" id="lc3" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Lodging Charges:</label>
          <input readonly type="number" class="form-control" id="lc6" name="lc6" placeholder="Total Amount" aria-label="Last name">
        </div>
        
      </div>

      <br>

      <div class="row">
        <div class="col-3">
          <p>Do you want to fill Conveyance charges?</p>
          <input type="radio" class="form-check-input" id="ccradio" name="ccoptradio" value="Yes" onclick="ccshow2();" required> Yes
          <label class="form-check-label" for="ccradio"> </label>
          <input type="radio" class="form-check-input" id="ccradio" name="ccoptradio" value="No" onclick="ccshow1();"> No
          <label class="form-check-label" for="ccradio"></label>
        </div>
        <div class="col" id="cc1" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Conv. Rate(Auto/Rikshaw fare) Per DAY:</label>
          <input type="number" class="form-control" id="cc4" name="cc4" placeholder="Amount" aria-label="Last name" onChange="multiply3()">
        </div>
        <div class="col" id="cc2" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">No of Days:</label>
          <input type="number" class="form-control" id="cc5" name="cc5" placeholder="Days" aria-label="Last name" onChange="multiply3()">
        </div>
        <div class="col" id="cc3" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Conveyance Charges:</label>
          <input readonly type="number" class="form-control" id="cc6" name="cc6" placeholder="Total Amount" aria-label="Last name">
        </div>

      </div>

      <br>
      <div class="row">
     

        <div class="col-3">
          <p>Do you want to fill Railway/Bus ticket charges?</p>
          <input type="radio" class="form-check-input" id="ticketradio" name="ticketoptradio" value="Yes" onclick="ticketshow2();" required> Yes
          <label class="form-check-label" for="ticketradio"> </label>
          <input type="radio" class="form-check-input" id="ticketradio" name="ticketoptradio" value="No" onclick="ticketshow1();"> No
          <label class="form-check-label" for="ticketradio"></label>
        </div>


        <div class="col" id="tt1" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Total no of tickets</label>
          <input type="number" class="form-control" id="tt4" name="tt4" placeholder="Total no of tickets" aria-label="Last name">
        </div>

        <div class="col" id="tt2" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Total ticket amount</label>
          <input type="number" class="form-control" id="tt5" name="tt5" placeholder="Total Amount" aria-label="Last name">
        </div>

       

      </div>
      <br>
      
      
      <hr>

<div class="row">
        <h6 class="text-left">Second Part of Journey</h6>
      </div>
      <br>
      <div class="row">
        <!-- <div class="col">
      <label for="exampleFormControlInput1" class="form-label">Total</label>
        <input  readonly type="number" class="form-control" id="cdac" name="cdac" placeholder="DA Charges" aria-label="Last name" >
    </div> -->
    
        <div class="col">
          <label for="city" class="form-label">Travelling City Type</label>
          <select class="form-select" aria-label="First Name" id="city" name='city' onChange="myFunction2()" required>
            <option value="">Select City</option>
            <?php
            $sql = mysqli_query($con, "SELECT * From city");
            $row = mysqli_num_rows($sql);
            while ($row = mysqli_fetch_array($sql)) {
              echo "<option value='" . $row['city_name'] . "'>" . $row['city_name'] . "</option>";
            }
            ?>
          </select>
        </div>

        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Max. DA Charges (For 24hrs)</label>
          <input readonly type="number" class="form-control" id="cdac" name="cdac" placeholder="DA Charges" aria-label="Last name">
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Max. Lodg. Charges (For 24hrs)</label>
          <input readonly type="number" class="form-control" id="clc" name="clc" placeholder="Lodging Charges" aria-label="Last name">
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Max. Conv. Charges (For 24hrs)</label>
          <input readonly type="number" class="form-control" id="ccc" name="ccc" placeholder="Conveyance Charges" aria-label="Last name">
        </div>

      </div>
      <div class="row">
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">From Station</label>
          <input type="text" class="form-control" style="text-transform: capitalize;" name="fromSation" placeholder="From Station" aria-label="Last name" required>
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">To Station</label>
          <input type="text" class="form-control" style="text-transform: capitalize;" name="toSataion" placeholder="To Station" aria-label="Last name" required>
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Total KMs of Travel</label>
          <input type="number" class="form-control" name="kmOfTravel" placeholder="Total Kilo-Meters of Travel" aria-label="First name" required>
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Start Date of Journey</label>
          <input type="datetime-local" class="form-control" id="Tod" name="Tod" placeholder="Time Of Diparture" aria-label="First name" required>
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">End Date of Journey</label>
          <input type="datetime-local" class="form-control" id="Toa" name="Toa" placeholder="Time Of Arrival" aria-label="Last name" onChange="myFunction()" required>
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Total Days of Travel</label>
          <input readonly type="number" class="form-control" id="daysOfTravel" name="daysOfTravel" placeholder="Total Days of Travel" aria-label="Last name" required>
        </div>
      </div>
      <br>

      <div class="row">
        <div class="col-3">
          <p>Do you want to fill DA Charges?</p>
          <input type="radio" class="form-check-input" id="daradio" name="daoptradio" value="Yes" onclick="dashow2();multiply();" required> Yes
          <label class="form-check-label" for="daradio"> </label>
          <input type="radio" class="form-check-input" id="daradio" name="daoptradio" value="No" onclick="dashow1();"> No
          <label class="form-check-label" for="daradio"></label>
        </div>
        <div class="col" id="da1" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">DA Rate Per DAY:</label>
          <input readonly min="0" type="number" class="form-control" id="da45" name="da45" placeholder="Amount" aria-label="Last name" onChange="multiply()">
        </div>
        <div class="col" id="da2" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">No of Days:</label>
          <input type="number" min="0" class="form-control" id="da5" name="da5" placeholder="Days" aria-label="Last name" onChange="multiply()">
        </div>
        <div class="col" id="da3" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">DA Charges:</label>
          <input readonly type="number" class="form-control" id="da6" name="da6" placeholder="Total Amount" aria-label="Last name">
        </div>
      </div>

      <br>

      <div class="row">
        <div class="col-3">
          <p>Do you want to fill Lodging Charges?</p>
          <input type="radio" class="form-check-input" id="lcradio" name="lcoptradio" value="Yes" onclick="lcshow2();multiply();" required> Yes
          <label class="form-check-label" for="lcradio"> </label>
          <input type="radio" class="form-check-input" id="lcradio" name="lcoptradio" value="No" onclick="lcshow1();"> No
          <label class="form-check-label" for="lcradio"></label>
        </div>
        <div class="col" id="lc1" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Lodging Rate Per DAY:</label>
          <input readonly type="number" class="form-control" id="lc45" name="lc45" placeholder="Amount" aria-label="Last name" onChange="multiply2()">
        </div>
        <div class="col" id="lc2" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">No of Days:</label>
          <input type="number" class="form-control" id="lc5" name="lc5" placeholder="Days" aria-label="Last name" onChange="multiply2()">
        </div>
        <div class="col" id="lc3" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Lodging Charges:</label>
          <input readonly type="number" class="form-control" id="lc6" name="lc6" placeholder="Total Amount" aria-label="Last name">
        </div>
        
      </div>

      <br>

      <div class="row">
        <div class="col-3">
          <p>Do you want to fill Conveyance charges?</p>
          <input type="radio" class="form-check-input" id="ccradio" name="ccoptradio" value="Yes" onclick="ccshow2();" required> Yes
          <label class="form-check-label" for="ccradio"> </label>
          <input type="radio" class="form-check-input" id="ccradio" name="ccoptradio" value="No" onclick="ccshow1();"> No
          <label class="form-check-label" for="ccradio"></label>
        </div>
        <div class="col" id="cc1" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Conv. Rate(Auto/Rikshaw fare) Per DAY:</label>
          <input type="number" class="form-control" id="cc4" name="cc4" placeholder="Amount" aria-label="Last name" onChange="multiply3()">
        </div>
        <div class="col" id="cc2" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">No of Days:</label>
          <input type="number" class="form-control" id="cc5" name="cc5" placeholder="Days" aria-label="Last name" onChange="multiply3()">
        </div>
        <div class="col" id="cc3" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Conveyance Charges:</label>
          <input readonly type="number" class="form-control" id="cc6" name="cc6" placeholder="Total Amount" aria-label="Last name">
        </div>
      </div>

     <br>
      <div class="row">
     

        <div class="col-3">
          <p>Do you want to fill Railway/Bus ticket charges?</p>
          <input type="radio" class="form-check-input" id="ticketradio" name="ticketoptradio" value="Yes" onclick="ticketshow2();" required> Yes
          <label class="form-check-label" for="ticketradio"> </label>
          <input type="radio" class="form-check-input" id="ticketradio" name="ticketoptradio" value="No" onclick="ticketshow1();"> No
          <label class="form-check-label" for="ticketradio"></label>
        </div>


        <div class="col" id="tt1" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Total no of tickets</label>
          <input type="number" class="form-control" id="tt4" name="tt4" placeholder="Total no of tickets" aria-label="Last name">
        </div>

        <div class="col" id="tt2" style="display: none">
          <label for="exampleFormControlInput1" class="form-label">Total ticket amount</label>
          <input type="number" class="form-control" id="tt5" name="tt5" placeholder="Total Amount" aria-label="Last name">
        </div>

        

      </div>
      <br>
      
      
     
      
      <div class="row">

      <div class="col" id="lc7">
          <label for="img">Upload Lodging Bills Here</label>
          <input type="file" id="fileUpload" name="fileUpload" />
        </div>

        <div class="col" id="tt3">
          <label for="img">Upload Tickets Here</label> <br>
          <input type="file" id="fileToUpload" name="fileToUpload" />
        </div>

        <div class="col-4">
          <label for="exampleFormControlInput1" class="form-label" style="display:block;">Click below button to get total amount: </label>
          <input type="button" value="Calculate Total" onclick="addn()" required />
        </div>

        <div class="col-4">
          <label for="exampleFormControlInput1" class="form-label">Total Amount</label>
          <input readonly type="text" class="form-control" id="ttl" name="ttl" placeholder="Total" aria-label="First name" required>
        </div>
        <div class="col-4">
          <label for="exampleFormControlInput1" class="form-label">Remark/Purpose</label>
          <textarea class="form-control" rows="3" style="text-transform: capitalize;" placeholder="Remark (if any)" name="remark" aria-label="Last name" required></textarea>

        </div>
      </div>

      <br>
      


      <!-- Calculate TA Bill not needed on user side -->

      <br>
      <center>
        <tr>


          <td>
            <button class="btn btn-primary" type="submit" name="submit" id="btn">Save</button>
          </td>

          <td>
            <button class="btn btn-danger" name="reset_form" id="btn_r" onClick="location.reload();">Reset</button>
          </td>

        </tr>
      </center>


			
  </div>
</div>


<!-- Java Script Get Started From here -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script>
$(document).ready(function(){
var i=1;
$('#add').click(function(){
i++;
$('#dynamic_field').append('<tr id="row1'+i+'"><td><input type="text" name="skill[]" placeholder="Enter your Skill" class="form-control name_list" /></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></td></tr>');
});
	
$(document).on('click', '.btn_remove', function(){
var button_id = $(this).attr("id"); 
$('#row1'+button_id+'').remove();
});
});
</script>

<script>
  function dashow1() {

    // document.getElementById('da45').value =null;
    document.getElementById("da5").value = null;
    document.getElementById("da6").value = null;
    document.getElementById('da1').style.display = 'none';
    document.getElementById('da2').style.display = 'none';
    document.getElementById('da3').style.display = 'none';
    document.getElementById('da45').required = false;
    document.getElementById("da5").required = false;
    document.getElementById("da6").required = false;

  }


  function dashow2() {
    document.getElementById('da1').style.display = 'block';
    document.getElementById('da2').style.display = 'block';
    document.getElementById('da3').style.display = 'block';
    document.getElementById('da45').required = true;
    document.getElementById("da5").required = true;
    document.getElementById("da6").required = true;


  }

  function lcshow1() {
    // document.getElementById("lc45").value =null;
    document.getElementById("lc5").value = null;
    document.getElementById("lc6").value = null;

    document.getElementById('lc1').style.display = 'none';
    document.getElementById('lc2').style.display = 'none';
    document.getElementById('lc3').style.display = 'none';
    
    // document.getElementById("lc45").required = false;
    document.getElementById("lc5").required = false;
    document.getElementById("lc6").required = false;
    // document.getElementById("lc7").required = false;

  }

  function lcshow2() {
    document.getElementById('lc1').style.display = 'block';
    document.getElementById('lc2').style.display = 'block';
    document.getElementById('lc3').style.display = 'block';
    // document.getElementById('lc7').style.display = 'block';
    document.getElementById("lc45").required = true;
    document.getElementById("lc5").required = true;
    document.getElementById("lc6").required = true;
    // document.getElementById("lc7").required = true;

  }

  function ccshow1() {
    document.getElementById("cc4").value = null;
    document.getElementById("cc5").value = null;
    document.getElementById("cc6").value = null;
    document.getElementById('cc1').style.display = 'none';
    document.getElementById('cc2').style.display = 'none';
    document.getElementById('cc3').style.display = 'none';
    document.getElementById("cc4").required = false;
    document.getElementById("cc5").required = false;
    document.getElementById("cc6").required = false;


  }

  function ccshow2() {
    document.getElementById('cc1').style.display = 'block';
    document.getElementById('cc2').style.display = 'block';
    document.getElementById('cc3').style.display = 'block';
    document.getElementById("cc4").required = true;
    document.getElementById("cc5").required = true;
    document.getElementById("cc6").required = true;
  }

  function ticketshow1() {
    document.getElementById("tt4").value = null;
    document.getElementById("tt5").value = null;

    document.getElementById('tt1').style.display = 'none';
    document.getElementById('tt2').style.display = 'none';
    //document.getElementById('tt3').style.display = 'none';
    document.getElementById("tt4").required = false;
    document.getElementById("tt5").required = false;
    document.getElementById("fileToUpload").required = false;
  }

  function ticketshow2() {
    document.getElementById('tt1').style.display = 'block';
    document.getElementById('tt2').style.display = 'block';
    //document.getElementById('tt3').style.display = 'block';
    document.getElementById("tt4").required = true;
    document.getElementById("tt5").required = true;
    document.getElementById("fileToUpload").required = true;
  }

  function multiply() {
    var val1 = document.getElementById('da45').value;
    var val2 = document.getElementById('da5').value;
    var mul = Number(val1) * Number(val2);
    document.getElementById('da6').value = mul;
  }

  function multiply2() {
    var val1 = document.getElementById('lc45').value;
    var val2 = document.getElementById('lc5').value;
    var mul = Number(val1) * Number(val2);
    document.getElementById('lc6').value = mul;
  }

  function multiply3() {
    var val1 = document.getElementById('cc4').value;
    var val2 = document.getElementById('cc5').value;
    var mul = Number(val1) * Number(val2);
    document.getElementById('cc6').value = mul;
  }

  function addn() {
    var val1 = document.getElementById('da6').value;
    var val2 = document.getElementById('lc6').value;
    var val3 = document.getElementById('cc6').value;
    var val4 = document.getElementById('tt5').value;
    var addn = Number(val1) + Number(val2) + Number(val3) + Number(val4);
    document.getElementById('ttl').value = addn;
  }
</script>



<script>
  document.querySelector("#Toa").addEventListener("change", myFunction);

  function myFunction() {

    //value start
    var start = Date.parse($("input#Tod").val()); //get timestamp

    //value end
    var end = Date.parse($("input#Toa").val()); //get timestamp

    totalHours = NaN;

    if (start < end) {
      totalHours = Math.floor((end - start) / 1000 / 60 / 60); //milliseconds: /1000 / 60 / 60

      days = Math.round(totalHours / 24);

    } else {
      alert('End Date of journey should be greater than Start Date !!!!');
    }
    $("#totalhour").val(totalHours);

    $("#daysOfTravel").val(days);


  }
</script>

</body>

</html>