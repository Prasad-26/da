<link rel="icon" href="fevicon.png"/>
<body onload="myFunction2()">
<script type="text/javascript" src="admin_condition.js" ></script>



<?php
include("header.php");
include("common/auth_session.php");
require('common/db.php');
date_default_timezone_set('Asia/Kolkata');
$userid=$_GET['uid'];

$query=mysqli_query($con,"select * from travel_data where tid='$userid'");
while($result=mysqli_fetch_array($query))

{
    $document_name=$result['document_name'];
    $lodging_bills=$result['lodging_bills'];
    $tickets_document=$result['tickets_document'];
    
    ?> 

<div class="card mb-4" style=" 
 background:linear-gradient(rgba(255,255,255,0.9), rgba(255,255,255,0.9)),url('./user/aucb_wm.png') no-repeat;
 background-position: center;
 background-size:55%;">
                        <!-- <h5 class="mt-2"><?php echo $result['name'];?>'s TA Bill</h5> -->
                            <div class="card-body">
                           
                               <strong><p style="font-size:20px;text-decoration: underline;">User Details:</p></strong>
                                <table class="table table-bordered table-striped " >
                                                              
                               
                                    <tr>

                                    <tr> 
                                       <th>First Name</th>
                                       <td><?php echo $result['first_name'];?></td> </tr>           
                                       <tr> 
                                       <th>Last Name</th>
                                       <td ><?php echo $result['last_name'];?></td> </tr>                       
                                       <tr> <th>Branch</th>
                                       <td><?php echo $result['branch'];?></td> </tr>
                                   
                                    <tr>
                                       <th >Designation</th>
                                       <td id="desig3"><?php echo $result['designation'];?></td></tr>
                                       <tr><th>City Type</th>
                                       <td id="city3"><?php echo $result['city'];?></td>
                                    </tr>
                                  
</table>
<br><hr><br>

<strong><p style="font-size:20px;text-decoration: underline;">Travel Details:</p></strong>
<table class="table table-bordered table-striped" >
                                   

                                    <thead>
                                        <tr>
                                        <th scope="col">From Station</th>
                                        <th scope="col">To Station</th>
                                        <th scope="col">Total Kilometer of Travel</th>
                                        <th scope="col">Departure Time</th>
                                        <th scope="col">Arrival Time</th>
                                        <th scope="col">Days Of Travel</th>
                                        </tr>
                                     </thead>
                                    <tbody>
                                        <tr>
                                        <td><?php echo $result['from_station'];?></td>
                                        <td><?php echo $result['to_station'];?></td>
                                        <td><?php echo $result['Km_of_travel'];?>&nbsp;km</td>
                                        <td><?php echo $result['departure_time'];?></td>
                                        <td><?php echo $result['arrival_time'];?></td>
                                        <td ><?php echo $result['days_of_travel'];?></td>
                                        </tr>
                                   </tbody>

                                     
                                       
</table><br>
<table class="table table-bordered table-striped table-primary" >
<thead>
                                        <tr>
                                        <th scope="col">DA was provided by Bank/Organization?</th>
                                        <th scope="col">DA Rate</th>
                                        <th scope="col">No of Days:</th>
                                        <th scope="col">DA Charges: </th>
                                        </tr>
                                     </thead>
                                    <tbody>
                                        <tr>
                                        <td><?php echo $result['da'];?></td>
                                        <td><?php echo $result['da_rate'];?></td>
                                        <td><?php echo $result['da_days'];?></td>
                                        <td><?php echo $result['da_charges'];?></td>
                                        
                                        </tr>
                                   </tbody>

                                   </table><br>

                                   <table class="table table-bordered table-striped table-success" style="width:30 px;"  >
                                <thead>
                                        <tr>
                                        <th scope="col">Lodging charges was provided by Bank/Organization?</th>
                                        <th scope="col">Lodging Rate</th>
                                        <th scope="col">No of Days</th>
                                        <th scope="col">Lodging Charges</th>
                                        <th scope="col">Download Lodging Bills</th>
                                        </tr>
                                     </thead>
                                    <tbody>
                                        <tr>
                                        <td><?php echo $result['lc'];?></td>
                                        <td><?php echo $result['lc_rate'];?></td>
                                        <td><?php echo $result['lc_days'];?></td>
                                        <td><?php echo $result['lc_charges'];?></td>
                                        <td><form method="post" action="download.php" name="download1">
                                        <input type="hidden" name="uid" value="<?php echo $result['tid'];?>">   
                                        <input type="hidden" name="lodging_bills" value="<?php echo $result['lodging_bills'];?>"> 
                                        <button class="btn btn-outline-success" name="submit1"  type="submit">Download</button></form>
                                       </td>
                                        </tr>
                                   </tbody>

                                   </table><br>

                                   <table class="table table-bordered table-striped table-danger" >
                                <thead>
                                        <tr>
                                        <th scope="col">Conveyance charges was provided by Bank/Organization?</th>
                                        <th scope="col">Conveyance Rate</th>
                                        <th scope="col">No of Days:</th>
                                        <th scope="col">Conveyance Charges:</th>
                                        </tr>
                                     </thead>
                                    <tbody>
                                        <tr>
                                        <td><?php echo $result['cc'];?></td>
                                        <td><?php echo $result['cc_rate'];?></td>
                                        <td><?php echo $result['cc_days'];?></td>
                                        <td><?php echo $result['cc_charges'];?></td>
                                        
                                        </tr>
                                   </tbody>

                                   </table><br>
                                   <table class="table table-bordered table-striped" >
                                <thead>
                                        <tr>
                                        <th scope="col">Railway/Bus tickets booked by Bank/Organization?</th>
                                        <th scope="col">Total no of tickets</th>
                                        <th scope="col">Total ticket amount</th>
                                        <th scope="col">Download Tickets</th>
                                        </tr>
                                     </thead>
                                    <tbody>
                                        <tr>
                                        <td ><?php echo $result['ticket'];?></td></td>
                                        <td><?php echo $result['totalno_ticket'];?></td>
                                        <td><?php echo $result['totalamount_ticket'];?></td>
                                        <td>
                                            <form method="post" action="download.php" name="download2">                                           
                                            <input type="hidden" name="tickets_document" value="<?php echo $result['tickets_document'];?>"> 
                                            <button class="btn btn-outline-secondary" name="submit2"  type="submit">Download</button>
                                           </form>
                                        </td>
                                                                              
                                        </tr>
                                   </tbody>

                                   </table><br>                              
                                   <table class="table table-bordered table-striped" >
                                <thead>
                                        <tr>
                                        <th scope="col" >Total Amount</th>
                                        <th scope="col">Remark</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Application Date</th>
                                        <th scope="col">Download Applicant TA Bill</th>
                                        <th scope="col">Approve/Reject Date</th>
                                        </tr>
                                     </thead>
                                    <tbody>
                                        <tr>
                                        <td >Rs.<?php echo $result['ttl'];?></td></td>
                                        <td><?php echo $result['Remark'];?></td>
                                        <strong><td id="sta"><?php echo $result['status'];
                                        if($result['status']=='Approved')
                                        {
                                           echo '<style>
                                                     #sta{color:green;font-weight:bold;}
                                                </style>';
                                        }
                                        if($result['status']=='Rejected')
                                        {
                                            echo '<style>
                                                      #sta{color:red;font-weight:bold;}
                                                </style>';
                                        }
                                        ?></td></strong>
                                        <td><?php echo $result['application_date'];?></td>                                       
                                        <td>
                                        <form method="post" action="download.php" name="download">
                                        <input type="hidden" name="document_name" value="<?php echo $result['document_name'];?>"> 
                                        <button class="btn btn-outline-secondary" name="submit3" type="submit">Download</button></form>
                                        </td>
                                        <td><?php echo $result['approval_date'];?></td>   
                                        
                                        </tr>
                                        
                                   </tbody>

                                   </table>
                                   <br><hr><br>
                                   <strong><p style="font-size:20px;text-decoration: underline;">Max. Allowed TA distribution for one day:</p></strong>
                                <p style="font-size:15px;">(This charges are according to employees designation and traveling city.)</p>
                                <div class="row">
                                <!-- <div class="col">
                                    <label for="exampleFormControlInput1" class="form-label">Max. TA Amount (For 24hrs)</label>
                                    <input readonly type="number" class="form-control" id="tta" name="tta" placeholder="TA Amount" aria-label="Last name"  value="<?php echo $result['max_da'];?>">
                                </div> -->
                                <div class="col">
                                    <label for="exampleFormControlInput1" class="form-label">Max. Allowed DA Charges (For 24hrs)</label>
                                        <input readonly type="number" class="form-control" id="cdac1" name="cdac1" placeholder="DA Charges" aria-label="Last name" value="<?php echo $result['max_da'];?>">
                                    </div>
                             <div class="col">
                                    <label for="exampleFormControlInput1" class="form-label">Max. Allowed Lodging Charges (For 24hrs)</label>
                                    <input readonly type="number" class="form-control" id="clc1" name="clc1" placeholder="Lodging Charges" aria-label="Last name" value="<?php echo $result['max_lc'];?>">
                                </div>
                                <div class="col">
                                    <label for="exampleFormControlInput1" class="form-label">Max. Allowed Conveyance Charges (For 24hrs)</label>
                                    <input readonly type="number" class="form-control" id="ccc1" name="ccc1" placeholder="Conveyance Charges" aria-label="Last name" value="<?php echo $result['max_cc'];?>">
                                </div>
                                </div> <br>   
                                                               
                               <center>
                               <table>
                               <tr>
                              
                               <td><a class="btn btn-primary" href="manage_user.php" name="back" id="btn" >Back</a> &nbsp;</td>
                               
                               
                               <?php 
                               
                               $ret=mysqli_query($con,"SELECT status FROM travel_data WHERE tid='$userid'");

                               while($row=mysqli_fetch_array($ret))
                               
                               {if($row['status']==null || $row['status']=='In Process') {?>   
                               <td> <a href="edit.php?uid=<?php echo $result['tid'];?>" class="btn btn-info" name="aedit" id="abtn" >Edit Applicant TA Bill</a>&nbsp;</td>
                               
                                <form method="post" action="">
                                <td> <button type="submit" name="approved" class="btn btn-success">Approve</button>&nbsp; &nbsp;</td>
                                <td><button type="submit" name="rejected" class="btn btn-danger">Reject</button> <td>
                                </form>
                            
                                <?php } }?>  
                                
                               
                                
                                </table>
                                </tr>
                                </center>
                                <?php
                                 $approve_date = date('Y-m-d');
                                //  echo $approve_date;
                               
                                if(isset($_POST['approved']))
                                {                                  
                                $query1=mysqli_query($con,"update travel_data SET status='Approved',approval_date=now() where tid='$userid'");
                                echo "<meta http-equiv='refresh' content='0'>";
                                // echo '<script>document.getElementById("status").style.color:"green"</script>';
                                echo '<script type="text/javascript">alert("TA Bill is Approved")</script>';
                                }
                                if(isset($_POST['rejected']))
                                {
                                $query2=mysqli_query($con,"update travel_data SET status='Rejected',approval_date=now() where tid='$userid'");
                                echo "<meta http-equiv='refresh' content='0'>";
                                // echo '<script>document.getElementById("status").style.color:"red"</script>';
                                echo '<script type="text/javascript">alert("TA Bill is Rejected")</script>';   
                                }
                                ?>    
                               
                           
                            </div>
                        </div>

                        
<?php 
} 
?>      

                     </div>
                </main>
                
            </div>
        </div>
      
        

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
        


    </body>
</html>
